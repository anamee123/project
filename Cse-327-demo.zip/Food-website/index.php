<?php include("headerforcart.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Website</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="c7e84f67-519e-4886-9a7b-0d96fdc5732d";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</head>
<body>
  <!-- header section starts      -->

 <header>

     <a href="#" class="logo"><i class="fas fa-utensils"></i>Bistro.</a>

     <nav class="navbar">
         <a class="active" href="#home">home</a>
         <a href="#dishes">dishes</a>
         <a href="#about">about</a>
         <a href="#menu">menu</a>
         <a href="#review">review</a>
         <a href="#order">order</a>
         <a href="logout.php">logout</a>
     </nav>

     <div class="icons">
         <i class="fas fa-bars" id="menu-bars"></i>
         <i class="fas fa-search" id="search-icon"></i>
         <a href="#" class="fas fa-heart"></a>
         <a href="#" class="fas fa-shopping-cart"></a>
     </div>

 </header>

 <!-- header section ends-->


 <!-- search form  -->

 <form action="" id="search-form">
     <input type="search" placeholder="search here..." name="" id="search-box">
     <label for="search-box" class="fas fa-search"></label>
     <i class="fas fa-times" id="close"></i>
 </form>

 <!-- home section starts  -->

 <section class="home" id="home">

     <div class="swiper-container home-slider">

         <div class="swiper-wrapper wrapper">

             <div class="swiper-slide slide">
                 <div class="content">
                     <span>our special dish</span>
                     <h3>spicy noodles</h3>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit natus dolor cumque?</p>
                     <a href="#" class="btn">order now</a>
                 </div>
                 <div class="image">
                     <img src="images/home-img-1.png" alt="">
                 </div>
             </div>

             <div class="swiper-slide slide">
                 <div class="content">
                     <span>our special dish</span>
                     <h3>fried chicken</h3>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit natus dolor cumque?</p>
                     <a href="#" class="btn">order now</a>
                 </div>
                 <div class="image">
                     <img src="images/home-img-2.png" alt="">
                 </div>
             </div>

             <div class="swiper-slide slide">
                 <div class="content">
                     <span>our special dish</span>
                     <h3>hot pizza</h3>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit natus dolor cumque?</p>
                     <a href="#" class="btn">order now</a>
                 </div>
                 <div class="image">
                     <img src="images/home-img-3.png" alt="">
                 </div>
             </div>

         </div>

         <div class="swiper-pagination"></div>

     </div>

 </section>

 <!-- home section ends -->

 <!-- dishes section starts  -->

 <section class="dishes" id="dishes">

     <h3 class="sub-heading"> our dishes </h3>
     <h1 class="heading"> popular dishes </h1>

     <div class="box-container">

       <form action="managecart.php" method="POST">
        <div class="card">
          <img src="images\dish-1.png" class="card-img-top" >
          <div class="card-body text-center">
            <h2 class="card-title">FOOD ITEM 1</h2>
            <p class="card-text">Price: ৳25</p>
            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart
            <input type="hidden" name="Item_Name" value="Food Item 1">
            <input type="hidden" name="Price" value="25">
          </div>
         </div>
       </form>
       <form action="managecart.php" method="POST">
        <div class="card">
          <img src="images\dish-5.png" class="card-img-top" >
          <div class="card-body text-center">
            <h2 class="card-title">FOOD ITEM 2</h2>
            <p class="card-text">Price: ৳35</p>
            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart
            <input type="hidden" name="Item_Name" value="Food Item 2">
            <input type="hidden" name="Price" value="35">
          </div>
         </div>
       </form>
       <form action="managecart.php" method="POST">
        <div class="card">
          <img src="images\dish-3.png" class="card-img-top" >
          <div class="card-body text-center">
            <h2 class="card-title">FOOD ITEM 3</h2>
            <p class="card-text">Price: ৳35</p>
            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart
            <input type="hidden" name="Item_Name" value="Food Item 3">
            <input type="hidden" name="Price" value="35">
          </div>
         </div>
       </form>
       <form action="managecart.php" method="POST">
        <div class="card">
          <img src="images\dish-4.png" class="card-img-top" >
          <div class="card-body text-center">
            <h2 class="card-title">FOOD ITEM 4</h2>
            <p class="card-text">Price: ৳25</p>
            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart
            <input type="hidden" name="Item_Name" value="Food Item 4">
            <input type="hidden" name="Price" value="25">
          </div>
         </div>
       </form>
       <form action="managecart.php" method="POST">
        <div class="card">
          <img src="images\dish-1.png" class="card-img-top" >
          <div class="card-body text-center">
            <h2 class="card-title">FOOD ITEM 5</h2>
            <p class="card-text">Price: ৳25</p>
            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart
            <input type="hidden" name="Item_Name" value="Food Item 4">
            <input type="hidden" name="Price" value="25">
          </div>
         </div>
       </form>
       <form action="managecart.php" method="POST">
        <div class="card">
          <img src="images\dish-4.png" class="card-img-top" >
          <div class="card-body text-center">
            <h2 class="card-title">FOOD ITEM 6</h2>
            <p class="card-text">Price: ৳25</p>
            <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart
            <input type="hidden" name="Item_Name" value="Food Item 4">
            <input type="hidden" name="Price" value="25">
          </div>
         </div>
       </form>

         <!--<form action="managecart.php" method="POST">
         <div class="box">
             <a href="#" class="fas fa-heart"></a>
             <a href="#" class="fas fa-eye"></a>
             <img src="images/dish-1.png" alt="">
             <h3>tasty food</h3>
             <div class="stars">
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star-half-alt"></i>
             </div>
             <span>bdt15.99</span>
             <a href="indexforcart.php" name="Add_To_Cart" class="btn">add to cart</a>
         </div>
       </form>
          <form action="managecart.php" method="POST">
         <div class="box">
             <a href="#" class="fas fa-heart"></a>
             <a href="#" class="fas fa-eye"></a>
             <img src="images/dish-2.png" alt="">
             <h3>tasty food</h3>
             <div class="stars">
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star-half-alt"></i>
             </div>
             <span>bdt15.99</span>
             <a href="indexforcart.php" name="Add_To_Cart" class="btn">add to cart</a>
         </div>
       </form>
        <form action="managecart.php" method="POST">
         <div class="box">
             <a href="#" class="fas fa-heart"></a>
             <a href="#" class="fas fa-eye"></a>
             <img src="images/dish-3.png" alt="">
             <h3>tasty food</h3>
             <div class="stars">
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star-half-alt"></i>
             </div>
             <span>bdt15.99</span>
             <a href="indexforcart.php" name="Add_To_Cart" class="btn">add to cart</a>
         </div>
       </form>
          <form action="managecart.php" method="POST">
         <div class="box">
             <a href="#" class="fas fa-heart"></a>
             <a href="#" class="fas fa-eye"></a>
             <img src="images/dish-4.png" alt="">
             <h3>tasty food</h3>
             <div class="stars">
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star-half-alt"></i>
             </div>
             <span>bdt15.99</span>
             <a href="indexforcart.php" name="Add_To_Cart" class="btn">add to cart</a>
         </div>
       </form>
        <form action="managecart.php" method="POST">
         <div class="box">
             <a href="#" class="fas fa-heart"></a>
             <a href="#" class="fas fa-eye"></a>
             <img src="images/dish-5.png" alt="">
             <h3>tasty food</h3>
             <div class="stars">
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star-half-alt"></i>
             </div>
             <span>bdt15.99</span>
             <a href="indexforcart.php" name="Add_To_Cart" class="btn">add to cart</a>
         </div>
       </form>
        <form action="managecart.php" method="POST">
         <div class="box">
             <a href="#" class="fas fa-heart"></a>
             <a href="#" class="fas fa-eye"></a>
             <img src="images/dish-6.png" alt="">
             <h3>tasty food</h3>
             <div class="stars">
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star"></i>
                 <i class="fas fa-star-half-alt"></i>
             </div>
             <span>bdt15.99</span>
             <a href="indexforcart.php" name="Add_To_Cart" class="btn">add to cart</a>
         </div>
       </form>-->

     </div>

 </section>

 <!-- dishes section ends -->

 <!-- about section starts  -->

 <section class="about" id="about">

     <h3 class="sub-heading"> about us </h3>
     <h1 class="heading"> why choose us? </h1>

     <div class="row">

         <div class="image">
             <img src="images/about-img.png" alt="">
         </div>

         <div class="content">
             <h3>best food in the country</h3>
             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore, sequi corrupti corporis quaerat voluptatem ipsam neque labore modi autem, saepe numquam quod reprehenderit rem? Tempora aut soluta odio corporis nihil!</p>
             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, nemo. Sit porro illo eos cumque deleniti iste alias, eum natus.</p>
             <div class="icons-container">
                 <div class="icons">
                     <i class="fas fa-shipping-fast"></i>
                     <span>free delivery</span>
                 </div>
                 <div class="icons">
                     <i class="fas fa-dollar-sign"></i>
                     <span>easy payments</span>
                 </div>
                 <div class="icons">
                     <i class="fas fa-headset"></i>
                     <span>24/7 service</span>
                 </div>
             </div>
             <a href="contact.php" class="btn">learn more</a>
         </div>

     </div>

 </section>

 <!-- about section ends -->

 <!-- menu section starts  -->

 <section class="menu" id="menu">

     <h3 class="sub-heading"> our menu </h3>
     <h1 class="heading"> today's speciality </h1>

     <div class="box-container">

         <div class="box">
             <div class="image">
                 <img src="images/menu-1.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-2.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-3.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-4.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-5.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-6.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-7.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-8.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

         <div class="box">
             <div class="image">
                 <img src="images/menu-9.jpg" alt="">
                 <a href="#" class="fas fa-heart"></a>
             </div>
             <div class="content">
                 <div class="stars">
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star"></i>
                     <i class="fas fa-star-half-alt"></i>
                 </div>
                 <h3>delicious food</h3>
                 <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi, accusantium.</p>
                 <a href="#" class="btn">add to cart</a>
                 <span class="price">৳12.99</span>
             </div>
         </div>

     </div>

 </section>

 <!-- menu section ends -->

 <!-- review section starts  -->

 <section class="review" id="review">

     <h3 class="sub-heading"> customer's review </h3>
     <h1 class="heading"> what they say </h1>

     <div class="swiper-container review-slider">

         <div class="swiper-wrapper">

             <div class="swiper-slide slide">
                 <i class="fas fa-quote-right"></i>
                 <div class="user">
                     <img src="images/pic-1.png" alt="">
                     <div class="user-info">
                         <h3>john deo</h3>
                         <div class="stars">
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star-half-alt"></i>
                         </div>
                     </div>
                 </div>
                 <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit fugiat consequuntur repellendus aperiam deserunt nihil, corporis fugit voluptatibus voluptate totam neque illo placeat eius quis laborum aspernatur quibusdam. Ipsum, magni.</p>
             </div>

             <div class="swiper-slide slide">
                 <i class="fas fa-quote-right"></i>
                 <div class="user">
                     <img src="images/pic-2.png" alt="">
                     <div class="user-info">
                         <h3>john deo</h3>
                         <div class="stars">
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star-half-alt"></i>
                         </div>
                     </div>
                 </div>
                 <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit fugiat consequuntur repellendus aperiam deserunt nihil, corporis fugit voluptatibus voluptate totam neque illo placeat eius quis laborum aspernatur quibusdam. Ipsum, magni.</p>
             </div>

             <div class="swiper-slide slide">
                 <i class="fas fa-quote-right"></i>
                 <div class="user">
                     <img src="images/pic-3.png" alt="">
                     <div class="user-info">
                         <h3>john deo</h3>
                         <div class="stars">
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star-half-alt"></i>
                         </div>
                     </div>
                 </div>
                 <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit fugiat consequuntur repellendus aperiam deserunt nihil, corporis fugit voluptatibus voluptate totam neque illo placeat eius quis laborum aspernatur quibusdam. Ipsum, magni.</p>
             </div>

             <div class="swiper-slide slide">
                 <i class="fas fa-quote-right"></i>
                 <div class="user">
                     <img src="images/pic-4.png" alt="">
                     <div class="user-info">
                         <h3>john deo</h3>
                         <div class="stars">
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star"></i>
                             <i class="fas fa-star-half-alt"></i>
                         </div>
                     </div>
                 </div>
                 <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit fugiat consequuntur repellendus aperiam deserunt nihil, corporis fugit voluptatibus voluptate totam neque illo placeat eius quis laborum aspernatur quibusdam. Ipsum, magni.</p>
             </div>

         </div>

     </div>

 </section>

 <!-- review section ends -->

 <!-- order section starts  -->

 <section class="order" id="order">

     <h3 class="sub-heading"> order now </h3>
     <h1 class="heading"> free and fast </h1>

     <form action="">

         <div class="inputBox">
             <div class="input">
                 <span>your name</span>
                 <input type="text" placeholder="enter your name">
             </div>
             <div class="input">
                 <span>your number</span>
                 <input type="number" placeholder="enter your number">
             </div>
         </div>
         <div class="inputBox">
             <div class="input">
                 <span>your order</span>
                 <input type="text" placeholder="enter food name">
             </div>
             <div class="input">
                 <span>additional food</span>
                 <input type="test" placeholder="extra with food">
             </div>
         </div>
         <div class="inputBox">
             <div class="input">
                 <span>how musch</span>
                 <input type="number" placeholder="how many orders">
             </div>
             <div class="input">
                 <span>date and time</span>
                 <input type="datetime-local">
             </div>
         </div>
         <div class="inputBox">
             <div class="input">
                 <span>your address</span>
                 <textarea name="" placeholder="enter your address" id="" cols="30" rows="10"></textarea>
             </div>
             <div class="input">
                 <span>your message</span>
                 <textarea name="" placeholder="enter your message" id="" cols="30" rows="10"></textarea>
             </div>
         </div>

         <input type="submit" value="order now" class="btn">

     </form>

 </section>

 <!-- order section ends -->

 <!-- footer section starts  -->

 <section class="footer">

     <div class="box-container">

         <div class="box">
             <h3>locations</h3>
             <a href="#">dhaka</a>
             <a href="#">rajshahi</a>
             <a href="#">barishal</a>
             <a href="#">comilla</a>
             <a href="#">chittagong</a>
         </div>

         <div class="box">
             <h3>quick links</h3>
             <a href="#">home</a>
             <a href="#">dishes</a>
             <a href="#">about</a>
             <a href="#">menu</a>
             <a href="#">reivew</a>
             <a href="#">order</a>
         </div>

         <div class="box">
             <h3>contact info</h3>
             <a href="#">+123-456-7890</a>
             <a href="#">+111-222-3333</a>
             <a href="#">shaikhanas@gmail.com</a>
             <a href="#">anasbhai@gmail.com</a>
             <a href="#">Dhaka-1209,Bangladesh</a>
         </div>

         <div class="box">
             <h3>follow us</h3>
             <a href="#">facebook</a>
             <a href="#">twitter</a>
             <a href="#">instagram</a>
             <a href="#">linkedin</a>
         </div>

     </div>

     <div class="credit"> Cse-327(PROJECT) <span>Group-4</span> </div>

 </section>

 <!-- footer section ends -->




 <!-- loader part  -->
 <div class="loader-container">
     <img src="images/loader.gif" alt="">
 </div>











<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

 <!-- custom js file link  -->
 <script src="js/script.js"></script>
</body>
</html>
