<!DOCTYPE html>
<html lang="en">
<head>

  <title>FOOD WEBSITE</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

<!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

  <!-- live chat -->
  <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="c7e84f67-519e-4886-9a7b-0d96fdc5732d";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
  <link rel="stylesheet" href="css/style.css">

</head>

<body>

   <!-- header section starts      -->

 <header>

<a href="#" class="logo"><i class="fas fa-utensils"></i>Bistro.</a>

<nav class="navbar">
    <a class="active" href="#home">home</a>
    <a href="#dishes">dishes</a>
    <a href="#about">about</a>
    <a href="#menu">menu</a>
    <a href="#review">review</a>
    <a href="#order">order</a>
    <a href="logout.php">logout</a>

</nav>

<div class="icons">
    <i class="fas fa-bars" id="menu-bars"></i>
    <i class="fas fa-search" id="search-icon"></i>
    <a href="#" class="fas fa-heart"></a>
    <a href="#" class="fas fa-shopping-cart"></a>
</div>

</header>

<!-- header section ends-->


<!-- search form  -->

<form action="" id="search-form">
<input type="search" placeholder="search here..." name="" id="search-box">
<label for="search-box" class="fas fa-search"></label>
<i class="fas fa-times" id="close"></i>
</form>


</br>
</br>
</br>
</br>
</br>
</br>
<div class="container-fluid bg-grey">
    <h2 class="text-center">CONTACT US</h2>
    <div class="row">
      <div class="col-sm-5">
        <p>Contact us and we'll get back to you within 24 hours.</p>
        <p><span class="glyphicon glyphicon-map-marker"></span>CSE327 Project<br>North South University<br>Dhaka,Bangladesh</p>
        <p><span class="glyphicon glyphicon-phone"></span>01233123. 01522111223</p>
        <p><span class="glyphicon glyphicon-envelope"></span> myemail@something.com</p>
      </div>

      <div class="col-sm-7">
        <form action="insert.php " method="post">
        <div class="row">
          <div class="col-sm-6 form-group">
            <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
          </div>
          <div class="col-sm-6 form-group">
            <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
          </div>
        </div>
        <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
        <div class="row">
          <div class="col-sm-12 form-group">
            <button class="btn btn-default pull-right" type="submit">Send</button>
          </div>
        </div>
      </div>
    </div>
  </form>
  </div>




<!-- Add Google Maps -->
<div id="googleMap">

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.0979538928823!2d90.42336791458314!3d23.81511559221881!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c64c103a8093%3A0xd660a4f50365294a!2sNorth%20South%20University!5e0!3m2!1sen!2sbd!4v1652424604241!5m2!1sen!2sbd" width="100%" height="400" frameborder="1" style="border:2" allowfullscreen></iframe>

</div>

</body>


<section class="footer">

<div class="box-container">

    <div class="box">
        <h3>locations</h3>
        <a href="#">dhaka</a>
        <a href="#">rajshahi</a>
        <a href="#">barishal</a>
        <a href="#">comilla</a>
        <a href="#">chittagong</a>
    </div>

    <div class="box">
        <h3>quick links</h3>
        <a href="#">home</a>
        <a href="#">dishes</a>
        <a href="#">about</a>
        <a href="#">menu</a>
        <a href="#">reivew</a>
        <a href="#">order</a>
    </div>

    <div class="box">
        <h3>contact info</h3>
        <a href="#">+123-456-7890</a>
        <a href="#">+111-222-3333</a>
        <a href="#">shaikhanas@gmail.com</a>
        <a href="#">anasbhai@gmail.com</a>
        <a href="#">Dhaka-1209,Bangladesh</a>
    </div>

    <div class="box">
        <h3>follow us</h3>
        <a href="#">facebook</a>
        <a href="#">twitter</a>
        <a href="#">instagram</a>
        <a href="#">linkedin</a>
    </div>

</div>

<div class="credit"> Cse-327(PROJECT) <span>Group-4</span> </div>

</section>

</html>
