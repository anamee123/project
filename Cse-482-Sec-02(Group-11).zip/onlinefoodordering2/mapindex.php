<?php
 require ('config/constants.php');
 if(isset($_POST["submit"])){
   $name = $_POST["name"];
   $email = $_POST["email"];
   $latitude = $_POST["latitude"];
   $longitude = $_POST["longitude"];

   $query = "INSERT INTO data VALUES('', '$name', '$email', '$latitude', '$longitude')";
   mysqli_query($conn, $query);

   echo
   "
   <script>
   alert('Food Item Delivery Done');
   documennt.location.href = 'data.php';
   </script>
   "
   ;
 }
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href=".css">
      <!--Link for fa font-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<body onload="getLocation();">
  <form class="container" action="" method="POST" autocomplete="off">
    <label for="">Name</label>
    <input type="text" name="name" required value=""><br><br>

    <label for="">Email</label>
    <input type="email" name="email" required value=""><br><br>
    <input type="hidden" name="latitude" required value="">
    <input type="hidden" name="longitude" required value="">

    <button type="submit" name="submit">Submit</button>
  </form>

  <script type="text/javascript">
    function getLocation(){
      if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showPosition,showError);
      }
    }
    function showPosition(position){
      document.querySelector('.container input[name = "latitude"]').value = position.coords.latitude;
      document.querySelector('.container input[name = "longitude"]').value = position.coords.longitude;
    }
    function showError(error){
      switch (error.code) {
        case error.PERMISSION_DENIED:
        alert("You Must Allow The Request For Geolocation To fill Out The Form");
        location.reload();
        break;
      }
    }
  </script>
  <br>
  <a href="data.php">Check Delivery-Man Location</a>
</body>
</html>
