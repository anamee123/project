<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href="style5.css">
      <!--Link for fa font-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<body>

    <!-- header section starts      -->

  <header>


      <nav class="navbar">
          <a class="active" href="home.php">Home</a>
          <a href="about us.php">About</a>
          <a href="foods.php">Foods</a>
          <a href="categories.php">Categories</a>
        
      </nav>

      <div class="icons">
          <i class="fas fa-bars" id="menu-bars"></i>
          <i class="fas fa-search" id="search-icon"></i>
          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="fas fa-shopping-cart"></a>
      </div>
     <div class="clearfix"></div>
  </header>

  <!-- header section ends-->
  <!-- fOOD sEARCH Section Starts Here -->
  <section class="food-search text-center">
      <div class="container">

          <form action="food-search.html" method="POST">
              <input type="search" name="search" placeholder="Search for Food.." required>
              <input type="submit" name="submit" value="Search" class="btn btn-primary">
          </form>

      </div>
  </section>
  <!-- fOOD sEARCH Section Ends Here -->

  <!-- CAtegories Section Starts Here -->
  <section class="categories">
      <div class="container">
          <h2 class="text-center">Explore Foods</h2>

          <a href="category-foods.html">
          <div class="box-3 float-container">
              <img src="dish-1.png" alt="Pizza" class="img-responsive img-curve">

              <h3 class="float-text text-white">Pizza</h3>
          </div>
          </a>

          <a href="#">
          <div class="box-3 float-container">
              <img src="dish-2.png" alt="Burger" class="img-responsive img-curve">

              <h3 class="float-text text-white">Burger</h3>
          </div>
          </a>

          <a href="#">
          <div class="box-3 float-container">
              <img src="dish-3.png" alt="Momo" class="img-responsive img-curve">

              <h3 class="float-text text-white">Momo</h3>
          </div>
          </a>

          <div class="clearfix"></div>
      </div>
  </section>
  <!-- Categories Section Ends Here -->
  <!-- fOOD MEnu Section Starts Here -->
  <section class="menu">
      <div class="box-container">
          <h2 class="text-center">Explore Menu</h2>
           <a href="categories-foods.html">

          <div class="box">
              <div class="image">
                  <img src="menu-1.jpg" alt="Chicken Hawain Pizza" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Sausage Pizza</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>

          <div class="box">
              <div class="image">
                  <img src="menu-2.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Smoky Burger</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>

          <div class="box">
              <div class="image">
                  <img src="menu-3.jpg" alt="Chicken Hawain Burger" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Laccha Parata</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>

          <div class="box">
              <div class="image">
                  <img src="menu-4.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Wraffle Desert</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>

          <div class="box">
              <div class="image">
                  <img src="menu-5.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Caramel Cake</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>

          <div class="box">
              <div class="image">
                  <img src="menu-6.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Chocolate Muffin</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>
          <div class="box">
              <div class="image">
                  <img src="menu-7.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Lemonade</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>
          <div class="box">
              <div class="image">
                  <img src="menu-8.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Fruit Salad</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>
          <div class="box">
              <div class="image">
                  <img src="menu-9.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Orange Juice</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>
          <div class="box">
              <div class="image">
                  <img src="menu-4.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
              </div>

              <div class="food-menu-desc">
                  <h4>Wraffle Desert</h4>
                  <p class="food-price">$2.3</p>
                  <p class="food-detail">
                      Made with Italian Sauce, Chicken, and organice vegetables.
                  </p>
                  <br>

                  <a href="#" class="btn btn-primary">Order Now</a>
              </div>
          </div>

          <div class="clearfix"></div>



      </div>

  </section>
  <!-- fOOD Menu Section Ends Here -->

  <!-- footer section starts  -->

 <section class="footer">

     <div class="box-container">

         <div class="box">
             <h3>Locations</h3>
             <a href="#">Banani</a>
             <a href="#">Gulshan</a>
             <a href="#">Bashundhara</a>
             <a href="#">Nikunju</a>
             <a href="#">Uttara</a>
         </div>

         <div class="box">
             <h3>Quick Links</h3>
             <a href="#">home</a>
             <a href="#">dishes</a>
             <a href="#">about</a>
             <a href="#">menu</a>
             <a href="#">reivew</a>
             <a href="#">order</a>
         </div>

         <div class="box">
             <h3>Contact Info</h3>
             <a href="#">+880-1921-7853</a>
             <a href="#">+111-222-333</a>
             <a href="#">khananamy002@gmail.com</a>
             <a href="#">humayra@gmail.com</a>
             <a href="#">Gulshan-Dhaka-1219</a>
         </div>

         <div class="box">
             <h3>Follow Us</h3>
             <a href="#">facebook</a>
             <a href="#">twitter</a>
             <a href="#">instagram</a>
             <a href="#">linkedin</a>
         </div>

     </div>

     <div class="credit"> copyright @ 2022 by <span>GROUP 11</span>
       <p>Sadiya Afrose Anamika & Humayra Akhter Oishee</p>
      </div>

 </section>
 </body>
 </html>
