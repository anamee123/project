<?php include('partials/menu.php');?>

      <!--Main content section starts-->
      <div class="main-content">
        <div class="wraper">
        <h1>Manage Admin</h1>

        <br /><br />
        <?php
           if(isset($_SESSION['add']))//checking session set or not
           {

               echo $_SESSION['add'];//display session massage
               unset($_SESSION['add']); //remove session message

           }
           if(isset($_SESSION['delete']))//checking session set or not
           {

               echo $_SESSION['delete'];//display session massage
               unset($_SESSION['delete']); //remove session message

           }
           if(isset($_SESSION['update']))//checking session set or not
           {

               echo $_SESSION['update'];//display session massage
               unset($_SESSION['update']); //remove session message

           }
           if(isset($_SESSION['user-not-found']))//checking session set or not
           {

               echo $_SESSION['user-not-found'];//display session massage
               unset($_SESSION['user-not-found']); //remove session message

           }
           if(isset($_SESSION['pass-not-match']))//checking session set or not
           {

               echo $_SESSION['pass-not-match'];//display session massage
               unset($_SESSION['pass-not-match']); //remove session message

           }
           if(isset($_SESSION['change-pass']))//checking session set or not
           {

               echo $_SESSION['change-pass'];//display session massage
               unset($_SESSION['change-pass']); //remove session message

           }

        ?>


     <br><br>
        <!--Button to add admin-->
        <a href="add-admin.php" class="btn-primary">Add Admin</a>
         <br /><br /><br />

        <table class="tbl-full">
          <tr>
            <th>Serial Number</th>
            <th>Full Name</th>
            <th>User Name</th>
            <th>Action</th>
          </tr>


          <?php
          //query to get all admin
          $sql = "SELECT * FROM admin";
          //execute the query
          $res = mysqli_query($conn, $sql);
          //check whether query is executed or not
          if($res==TRUE)
          {
            //count rows
            $count = mysqli_num_rows($res); //function to get all the rows
            $sn=1;
             //check num of rows
             if($count>0)
             {
               while($rows=mysqli_fetch_assoc($res))
               {
                 //using loop to get all data
                 $id=$rows['ID'];
                 $full_name=$rows['full_name'];
                 $username=$rows['username'];

                 ?>

                 <tr>
                   <td><?php echo $sn++; ?></td>
                   <td><?php echo $full_name; ?></td>
                   <td><?php echo $username; ?></td>
                   <td>
                     <a href="<?php echo SITEURL; ?>admin/update-password.php?id=<?php echo $id; ?>" class="btn-primary">Change Password</a>
                     <a href="<?php echo SITEURL; ?>admin/update-admin.php?id=<?php echo $id; ?>" class="btn-secondary">Update Admin</a>
                     <a href="<?php echo SITEURL; ?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-danger">Delete Admin</a>
                   </td>
                 </tr>

                 <?php

               }
             }
             else
             {

             }

          }



          ?>



        </table>



      </div>
    </div>
      <!--Main content section ends-->

<?php include('partials/footer.php'); ?>
