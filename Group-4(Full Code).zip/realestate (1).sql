-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 18, 2021 at 10:43 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realestate`
--

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
CREATE TABLE IF NOT EXISTS `agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `office` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`id`, `name`, `office`, `number`) VALUES
(1, 'Mr.Wahid', 'Banani', '01731582475'),
(2, 'Mr.Nurul', 'Banani', '01731582479');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(2225) NOT NULL,
  `location` varchar(222) NOT NULL,
  `number` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `name`, `location`, `number`, `email`) VALUES
(1, 'Mr.Sheikh', 'uttara', '01685370455', 'abc@gmail.com'),
(2, 'Mr.Rahman', 'bashundhara', '01685370456', 'xyz@gmail.com'),
(3, 'Mr.Mahin', 'bashundhara', '01731582477', 'xyz@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

DROP TABLE IF EXISTS `owner`;
CREATE TABLE IF NOT EXISTS `owner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`id`, `name`, `number`) VALUES
(1, 'Mr.Atique', '01717881734'),
(2, 'Mr.Mahin', '01686369848');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

DROP TABLE IF EXISTS `property`;
CREATE TABLE IF NOT EXISTS `property` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) NOT NULL,
  `contact` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `location`, `contact`, `email`, `image`) VALUES
(1, 'Dhanmondi', '01687766781', 'xyz@gmail.com', 'image/p0.jpg'),
(2, 'Nikunju-1', '0178693933', 'xyz@gmail.com', 'image/p1.jpg'),
(3, 'Nikunju-2', '01984740440', 'abc@xyz.com', 'image/p3.jpg'),
(4, 'Gulshan-1', '0198474044', 'xyz@abc.com', 'image/p5.jpeg'),
(5, 'Gulshan-2', '01921178856', 'pqr@gmail.com', 'image/p7.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `Email`, `Phone`, `Location`) VALUES
(1, 'rahima', '123456', 'rahima.khatun@gmail.com', '01800000001', 'Bogora'),
(2, 'Anamika', '123456', 'khananamy002@gmail.com', '01710405628', 'Bashundhara');

-- --------------------------------------------------------

--
-- Table structure for table `userproperty`
--

DROP TABLE IF EXISTS `userproperty`;
CREATE TABLE IF NOT EXISTS `userproperty` (
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userproperty`
--

INSERT INTO `userproperty` (`uid`, `username`, `id`, `location`) VALUES
(1, 'abc', 1, '..'),
(NULL, '', 3, 'Nikunju-2'),
(NULL, '', 4, 'Gulshan-1'),
(NULL, '', 3, 'Nikunju-2');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
