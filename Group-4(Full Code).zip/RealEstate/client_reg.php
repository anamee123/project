<?php
   include("config.php");
   session_start();
   $error=" ";

   if(isset($_POST['submit-reg'])) {

        $name = mysqli_real_escape_string($db,$_POST['name']);
        $number = mysqli_real_escape_string($db,$_POST['number']);
        $location = mysqli_real_escape_string($db,$_POST['location']);
        $email = mysqli_real_escape_string($db,$_POST['email']);

      $sql = "SELECT id FROM client WHERE name = '$name' and number = '$number' and location = '$location' and email = '$email'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $count = mysqli_num_rows($result);


      if($count == 1) {
         $_SESSION['login_client'] = $email;
         header("location: list.php");
      }else {
         $error = "Your Information is invalid";
      }
   }

   if(isset($_POST['submit'])) {

      $name = mysqli_real_escape_string($db,$_POST['name']);
      $number = mysqli_real_escape_string($db,$_POST['number']);
      $office = mysqli_real_escape_string($db,$_POST['office']);


    $sql = "SELECT id FROM agent WHERE name = '$name' and number = '$number' and office = '$office'";
    $result = mysqli_query($db,$sql);
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);


    if($count == 1) {
       $_SESSION['login_client'] = $email;
       header("location: list.php");
    }else {
       $error = "Your Information is invalid";
    }
 }

 if(isset($_POST['submit-log'])) {

   $name = mysqli_real_escape_string($db,$_POST['name']);
   $number = mysqli_real_escape_string($db,$_POST['number']);


 $sql = "SELECT id FROM owner WHERE name = '$name' and number = '$number'";
 $result = mysqli_query($db,$sql);
 $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
 $count = mysqli_num_rows($result);


 if($count == 1) {
    $_SESSION['login_client'] = $email;
    header("location: list.php");
 }else {
    $error = "Your Information is invalid";
 }
}




?>









<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Registration</title>

      <link rel="stylesheet" href="reg.css">

   </head>

   <body>

      <div class="Register">

          <div class="form-box">
              <div class="button-box">
                  <div id="btn"></div>


                 <button type="button" class="toggle-btn" onclick="Register()">Client Register</button>
                 <button type="button" class="toggle-btn" onclick="Submit()">Agent</button>
                 <button type="button" class="toggle-btn" onclick="SignIn()">Owner</button>

              </div>

              <div class="social-logo">

                  <img src="gp.png">

                  <img src="fb.png">

                  <img src="tw.png">

              </div>

              <form action="" method="post"  id="Client-Register" class="input-group">
                   <input type="text" class="input-field" placeholder="Name" name="name" required>
                   <input type="text" class="input-field" placeholder="Location" name="location" required>
                   <input type="number" class="input-field"
                      placeholder="Number" name="number" required>
                      <input type="text" class="input-field" placeholder="Enter valid mail" name="email" required>
                     <button type="submit" class="submit-btn" name = "submit-reg" id="submit-reg">Register</button>

              </form>

              <form action="" method="post" id="Agent" class="input-group">

                  <input type="text" class="input-field" placeholder="Name" name="name" required>
                   <input type="text" class="input-field" placeholder="Office" name="office" required>

                  <input type="number" class="input-field" placeholder="Number" name="number" required>
                   <button type="submit" class="submit-btn"  name = "submit" id="submit">Submit</button>

              </form>

              <form action="" method="post" id="Owner" class="input-group">
                   <input type="text" class="input-field" placeholder="Name" name="name" required>
                   <input type="number" class="input-field" placeholder="Number" name="number" required>
                    <button type="sign in" class="submit-btn" name = "submit-log" id="submit-log">Sign In</button>

              </form>
          </div>

      </div>
      <script src="app.js"></script>
   </body>
   </html>
