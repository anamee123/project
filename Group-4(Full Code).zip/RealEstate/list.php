<!DOCTYPE html>
<html>
<head>
  <title>ULTA Property</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="hero">
    <nav>
      <div class="logo">
        <img src="images/logo.png">
      </div>


      <button type="button" name="button" onclick="listproperty()">List Property</button>
      <select class="list">
        <option value="dhanmondi">Dhanmondi</option>
        <option value="gulshan">Gulshan</option>
        <option value="nikunju">Nikunju</option>
      </select>


      <img src="images/menu.png" class="menu-icon">

    </nav>
    <div class="row">
      <div class="col-1">
        <h1>Explore<br>"ULTA Property"</h1>
        <p>You Can Explore The Best Property Just Near Your Location In Reasonable Price.</p>
        <a href="client_reg.php"><button type="btn">Check Properties</a></button>
        <ul>
          <li class="btn active"></li>
          <li class="btn"></li>
          <li class="btn"></li>
        </ul>


      </div>
      <div class="col-2">
        <img src="images/pic1.png" id="banner">
      </div>
    </div>

  </div>
  <script>
     var btn = document.getElementsByClassName("btn");
     var banner = document.getElementById("banner");
     btn[0].onclick = function () {
       banner.src = "images/pic1.png";
       animation();
       this.classList.add("active");
     }

     btn[1].onclick = function () {
       banner.src = "images/pic2.png";
       animation();
       this.classList.add("active");
     }

     btn[2].onclick = function () {
       banner.src = "images/pic3.png";
       animation();
       this.classList.add("active");
     }

     function animation(){
       banner.classList.add("zoom");
       setTimeout(function(){
         banner.classList.remove("zoom");
       },500);

       for(b of btn){
         b.classList.remove("active");
       }

     }
  </script>




</body>
</html>
