<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>INSERT PRODUCT</title>
    <link rel="stylesheet" href="style.css">

        <meta charset="UTF-8">
    <title>Category</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 20px;
  left: 10px;
  background: #eee;
  overflow-x: hidden;
  padding: 8px 0;
 margin-top: 100px;
font-size: 12.5px;

font-weight: 700;


}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 12.5px;
  color: #2196F3;
  display: block;
}

.sidenav a:hover {
  color: #064579;
}

.form{

        font-family: 'Open Sans Condensed', arial, sans;
	width: 500px;
	padding: 30px;
	background: #FFFFFF;
	margin: 50px auto;
	box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
	-moz-box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
	-webkit-box-shadow:  0px 0px 15px rgba(0, 0, 0, 0.22);


    }








</style>
</head>
<body>

<?php
    $db = mysqli_connect( 'localhost', 'root', '', 'realestate' );

    $id = $_GET['id'];

    $query = "SELECT * FROM `property`
 WHERE id = '$id'";
    $data = mysqli_query( $db, $query );
    $total = mysqli_num_rows( $data );
    if ( $total != 0 ) {
        while ( $result = mysqli_fetch_assoc( $data ) ) {



		?>

     <div class="form">
  <form action="configuration.php" method="get"  enctype="multipart/form-data">

Property_Id<br>
<input type="text" name="id" value="<?php echo $result['id']; ?>" readonly>
<br><br>
Property_Location<br>
<input type="text" name="location" value="<?php echo $result['location']; ?>" readonly>
<br><br>

Property_Price<br />
<input type="number" name="number" placeholder="number" required>
<br /><br />
<br /><br />

<input type="submit" name="propertyadd" value="Upload"/>
</form>


    </div>
	<?php

		}
	}

	?>

</body>
</html>
