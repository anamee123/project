<?php
if(isset($_GET['propertyadd']))
{



	$id = $_GET['id'];
    $location = $_GET['location'];
	$username = $_GET['username'];



	$db = mysqli_connect("localhost","root","","realestate");
    $query= "INSERT INTO `userproperty`(`username`, `id`, `location`) VALUES ('$username','$id','$location')";

	$data=mysqli_query($db , $query);

	if($data){


		header ("location:file.php");



	}


	else{

	echo"DATA DO NOT UPDATE";
}



}
?>
