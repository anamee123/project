<?php
include('config.php');
?>




</<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Real Estate Property</title>
    <link rel="stylesheet" href="style2.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>

    <div class="menu-bar">


    <ul>

      <li class="active"><a href="file.php">Home</a><i class="fas fa-home"></i></li>
      <li><a href="#">Contact</a><i class="fas fa-phone"></i>
        <div class="sub-menu1">
          <ul>
            <li><a href="mailto:someone@example.com">Email Id</a></li>
            <li><a href="#">Phone Number</a></li>
          </ul>
        </div>

      </li>
      <li><a href="#">Service</a><i class="fas fa-clone"></i>
        <div class="sub-menu1">
          <ul>
            <li><a href="https://www.google.com/">Google</a></li>
            <li><a href="https://twitter.com/login?lang=en">Twitter</a></li>
          </ul>
        </div>
     </li>
      <li><a href="#">Rent</a><i class="fas fa-home"></i>
        <div class="sub-menu1">
          <ul>
            <li><a href="#">Dhanmondi Property Rent</a></li>
            <li class="hover-me"><a href="#">Nikunju Property Rent</a><i class="fa fa-angle-right"></i>
              <div class="sub-menu2">
                <ul>
                  <li><a href="#">Nikunju-1</a></li>
                  <li><a href="#">Nikunju-2</a></li>
                </ul>
              </div>

            </li>
            <li class="hover-me"><a href="#">Gulshan Property Rent</a><i class="fa fa-angle-right"></i>
              <div class="sub-menu2">
                <ul>
                  <li><a href="#">Gulshan-1</a></li>
                  <li><a href="#">Gulshan-2</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
     </li>
      <li><a href="#">Sale</a><i class="fas fa-home"></i>
        <div class="sub-menu1">
          <ul>
            <li><a href="#">Dhanmondi Property Sale</a></li>
            <li class="hover-me"><a href="#">Nikunju Property Sale</a><i class="fa fa-angle-right"></i>
              <div class="sub-menu2">
                <ul>
                  <li><a href="#">Nikunju-1</a></li>
                  <li><a href="#">Nikunju-2</a></li>
                </ul>

              </div>
            </li>
            <li class="hover-me"><a href="#">Gulshan Property Sale</a><i class="fa fa-angle-right"></i>
              <div class="sub-menu2">
                <ul>
                  <li><a href="#">Gulshan-1</a></li>
                  <li><a href="#">Gulshan-2</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
     </li>
      <li><a href="client_reg.php">Clients</a><i class="fas fa-users"></i></li>
      <li><a href="client_reg.php">Agents</a><i class="fas fa-home"></i></li>
      <li><a href="#">Pricing</a><i class="fas fa-dollar-sign"></i></li>
      <li><a href="#">About Us</a><i class="fas fa-user"></i></li>
      </ul>
   </div>


     <form action="searchresult.php" method="get" class="searchform">

           <input class="search-txt" type="text" placeholder="Search.." name="search" required >
           <button type = "submit" name="searchbar"><a class="search-btn" href=""><i class="fa fa-search"></i></a></button>

     </form>
      <div class="container">
     <div class="gallery">
       <img src="image/p0.jpg">
       <div class="desc"><a href="#">Dhanmondi</a></div>
       <div class="button-box">
	     <button type="button" class="toggle-btn">
		 <?php
		      $db = mysqli_connect("localhost","root","","realestate");
               $query="SELECT * FROM `property` WHERE location ='Dhanmondi'";
               $data=mysqli_query($db , $query);
               $total = mysqli_num_rows($data);
			   while ($result = mysqli_fetch_assoc($data)) {


			   echo"<a href = 'addproperty.php?id=$result[id]&location=$result[location]'>Add Property</a>";

			   }

			    ?>


				</button>

         <button type="button" class="toggle-btn" onclick="call()">Call</button>
         <button type="button" class="toggle-btn" onclick="email()">Email</button>
         <a href="#"><input type="button" class="btn" onclick="reset()" value="Reset"></a>

       </div>
     </div>
     <div class="gallery">
       <img src="image/p1.jpg">
       <div class="desc"><a href="#">Nikunju-1</a></div>
       <div class="button-box">

		 <button type="button" class="toggle-btn">
		 <?php
		      $db = mysqli_connect("localhost","root","","realestate");
               $query="SELECT * FROM `property` WHERE location ='Nikunju-1'";
               $data=mysqli_query($db , $query);
               $total = mysqli_num_rows($data);
			   while ($result = mysqli_fetch_assoc($data)) {


			   echo"<a href = 'addproperty.php?id=$result[id]&location=$result[location]'>Add Property</a>";

			   }

			    ?>


				</button>

         <button type="button" class="toggle-btn" onclick="call()">Call</button>
         <button type="button" class="toggle-btn" onclick="email()">Email</button>
         <a href="#"><input type="button" class="btn" onclick="reset()" value="Reset"></a>

       </div>
     </div>
     <div class="gallery">
       <img src="image/p3.jpg">
       <div class="desc"><a href="#">Nikunju-2</a></div>
       <div class="button-box">


		 <button type="button" class="toggle-btn">
		 <?php
		      $db = mysqli_connect("localhost","root","","realestate");
               $query="SELECT * FROM `property` WHERE location ='Nikunju-2'";
               $data=mysqli_query($db , $query);
               $total = mysqli_num_rows($data);
			   while ($result = mysqli_fetch_assoc($data)) {


			   echo"<a href = 'addproperty.php?id=$result[id]&location=$result[location]'>Add Property</a>";

			   }

			    ?>


				</button>





         <button type="button" class="toggle-btn" onclick="call()">Call</button>
         <button type="button" class="toggle-btn" onclick="email()">Email</button>
         <a href="#"><input type="button" class="btn" onclick="reset()" value="Reset"></a>

       </div>
     </div>
     <div class="gallery">
       <img src="image/p5.jpeg">
       <div class="desc"><a href="#">Gulshan-1</a></div>
       <div class="button-box">
         <button type="button" class="toggle-btn">
		 <?php
		      $db = mysqli_connect("localhost","root","","realestate");
               $query="SELECT * FROM `property` WHERE location ='Gulshan-1'";
               $data=mysqli_query($db , $query);
               $total = mysqli_num_rows($data);
			   while ($result = mysqli_fetch_assoc($data)) {


			   echo"<a href = 'addproperty.php?id=$result[id]&location=$result[location]'>Add Property</a>";

			   }

			    ?>


				</button>
         <button type="button" class="toggle-btn" onclick="call()">Call</button>
         <button type="button" class="toggle-btn" onclick="email()">Email</button>
         <a href="#"><input type="button" class="btn" onclick="reset()" value="Reset"></a>

       </div>
     </div>
     <div class="gallery">
       <img src="image/p7.jpeg">
       <div class="desc"><a href="#">Gulshan-2</a></div>
       <div class="button-box">
         <button type="button" class="toggle-btn">
		 <?php
		      $db = mysqli_connect("localhost","root","","realestate");
               $query="SELECT * FROM `property` WHERE location ='Gulshan-2'";
               $data=mysqli_query($db , $query);
               $total = mysqli_num_rows($data);
			   while ($result = mysqli_fetch_assoc($data)) {


			   echo"<a href = 'addproperty.php?id=$result[id]&location=$result[location]'>Add Property</a>";

			   }

			    ?>


				</button>
         <button type="button" class="toggle-btn" onclick="call()">Call</button>
         <button type="button" class="toggle-btn" onclick="email()">Email</button>
         <a href="#"><input type="button" class="btn" onclick="reset()" value="Reset"></a>

       </div>
     </div>




   </div>
   <script>
      //function add() {

		//header("location:addproperty.php");
		//alert("Notification Send");
  // }
   </script>

   <script>
      function email() {
        alert("Notification Send");

   }
   </script>


  </body>
</html>
