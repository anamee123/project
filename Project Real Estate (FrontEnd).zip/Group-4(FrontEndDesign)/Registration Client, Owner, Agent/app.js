function Register() {
   let register = document.getElementById("Client-Register");
   document.getElementById("Agent").style.display = "none";
   document.getElementById("Owner").style.display = "none";
   register.style.display = "block";


   let btn = document.getElementById("btn");
   btn.style.left = "0%";
   btn.style.width = "95px";

}

function Submit() {
   let agent = document.getElementById("Agent");
   document.getElementById("Client-Register").style.display = "none";
   document.getElementById("Owner").style.display = "none";
   agent.style.display = "block";

   let btn = document.getElementById("btn");
   btn.style.left = "42%";
   btn.style.width = "65px";

}

function SignIn() {
   let owner = document.getElementById("Owner");
   document.getElementById("Agent").style.display = "none";
   document.getElementById("Client-Register").style.display = "none";
   owner.style.display = "block";

   let btn = document.getElementById("btn");
   btn.style.left = "66%";
   btn.style.width = "80px";
}
