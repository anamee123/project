<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--for cookies-->
    <meta name="description" content="FOODIST uses cookies on its websites to improve usability and user experience. By continued use of this site, you consent to Profoto storing and using cookies. If you do not consent, go to your browser settings to manage cookies or discontinue using this site." />

    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href="style.css">

      <!--Link for fa font-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


    <script>
    function setCookie(cname,cvalue,exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

  function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  let user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
     user = prompt("We accept all your cookies and enhance to browsing experience:","");
     if (user != "" && user != null) {
       setCookie("username", user, 30);
     }
  }
}
</script>

</head>
<body onload="checkCookie()">




    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h3 class="logo">FOODIES</h3>
            </div>

            <div class="menu">
              <form action="login.php" method="post">
                <ul>
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="foods.php">FOODS</a></li>
                    <li><a href="categories.php">CATEGORIES</a></li>
                    <li><a href="mapindex.php">DELIVERY</a></li>
                    <li><a href="logout.php">LOGOUT</a></li>

                </ul>
              </form>
            </div>



        </div>
        <div class="content">
            <h1>Welcome to <br><span>FOODIES</span> <br>Online Food Ordering Service</h1>
                </div>
        </div>

        <br><br>
        <hr>
        <br>

        <!--section for contact us-->

        <section id="contact-section">
          <div class="container">
            <h2>Contact Us</h2>
            <br>
            <p>Email us and keep yourself trendy with our latest update</p>
            <br>
            <div class="contact-form">

              <!--first grid section-->
              <div>
                <i class="fa fa-map-marker"></i><span class="form-info">192 Pink City Gulshan</span><br>
                <i class="fa fa-phone"></i><span class="form-info">Phone No. +880 1921178753</span><br>
                <i class="fa fa-envelope"></i><span class="form-info">khananamy002@gmail.com</span><br>
              </div>
              <!--second grid-->
              <div>
                <form>
                  <input type="text" placeholder="First Name" required>
                  <input type="text" placeholder="Last Name" required>
                  <input type="Email" placeholder="Email" required>
                  <input type="text" placeholder="Topic" required>
                  <textarea name="message" placeholder="Message" rows="5" required></textarea>
                  <button class="submit">Send Message</button>
                </form>
                <br>

              </div>
                 <div> <i class='fas fa-map-marker-alt' style='font-size:88px;color:red'></i></div>
                <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.7367521562287!2d90.41364311397352!3d23.79238679309019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7a1348366e5%3A0x7d15a444ecad8568!2sGulshan%20Pink%20City%20Shopping%20Center%2C%20Gulshan%20Ave%2C%20Dhaka%201212!5e0!3m2!1sen!2sbd!4v1646520364453!5m2!1sen!2sbd" width="auto" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>

          </div>
    </section>

    <br><br>
    <hr>
    <br>



 <!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>Locations</h3>
            <a href="#">Banani</a>
            <a href="#">Gulshan</a>
            <a href="#">Bashundhara</a>
            <a href="#">Nikunju</a>
            <a href="#">Uttara</a>
        </div>

        <div class="box">
            <h3>Quick Links</h3>
            <a href="#">home</a>
            <a href="#">dishes</a>
            <a href="#">about</a>
            <a href="#">menu</a>
            <a href="#">reivew</a>
            <a href="#">order</a>
        </div>

        <div class="box">
            <h3>Contact Info</h3>
            <a href="#">+880-1921-7853</a>
            <a href="#">+111-222-333</a>
            <a href="#">khananamy002@gmail.com</a>
            <a href="#">humayra@gmail.com</a>
            <a href="#">Gulshan-Dhaka-1219</a>
        </div>

        <div class="box">
            <h3>Follow Us</h3>
            <a href="#">facebook</a>
            <a href="#">twitter</a>
            <a href="#">instagram</a>
            <a href="#">linkedin</a>
        </div>

    </div>

    <div class="credit"> copyright @ 2022 by <span>GROUP 11</span>
      <p>Sadiya Afrose Anamika & Humayra Akhter Oishee</p>
     </div>

</section>

</body>
</html>
