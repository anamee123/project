<?php include('config/constants.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href="style3.css">
    <!--Link for fa font-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

</head>
<body>
  <!-- header section starts      -->

<header>


    <nav class="navbar">
        <a class="active" href="<?php echo SITEURL; ?>">Home</a>
        <a href="<?php echo SITEURL; ?>about us.php">About</a>
        <a href="<?php echo SITEURL; ?>foods.php">Foods</a>
        <a href="<?php echo SITEURL; ?>categories.php">Categories</a>

    </nav>

    <div class="icons">
        <i class="fas fa-bars" id="menu-bars"></i>
        <i class="fas fa-search" id="search-icon"></i>
        <a href="#" class="fas fa-heart"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
    </div>
    <div class="clearfix"></div>

</header>

<!-- header section ends-->
<!-- home section starts  -->

<section class="home" id="home">


  <div class="swiper home-slider">

      <div class="swiper-wrapper wrapper">

          <div class="swiper-slide slide">
              <div class="content">
                  <span>Our Special Dish</span>
                  <h3>Spicy Noodles</h3>
                  <p>Wanna try some fresh and juicy tasty foods?</p>
                  <a href="#" class="btn">Order Now</a>
              </div>

              <div class="image">
                  <img src="home-img-1.png" alt="">
              </div>
          </div>

          <div class="swiper-slide slide">
              <div class="content">
                  <span>Our Special Dish</span>
                  <h3>Fried Chicken</h3>
                  <p>Wanna try some fresh and juicy tasty foods?</p>
                  <a href="#" class="btn">Order Now</a>
              </div>
              <div class="image">
                  <img src="home-img-2.png" alt="">
              </div>
          </div>

          <div class="swiper-slide slide">
              <div class="content">
                  <span>Our Special Dish</span>
                  <h3>Hot Pizza</h3>
                  <p>Wanna try some fresh and juicy tasty foods?</p>
                  <a href="#" class="btn">Order Now</a>
              </div>
              <div class="image">
                  <img src="home-img-3.png" alt="">
              </div>
          </div>

      </div>

      <div class="swiper-pagination"></div>

  </div>

</section>

<!-- home section ends -->
<script src="script1.js"></script>
<!-- Initialize Swiper -->
 <script>
 
   var swiper = new Swiper(".home-slider", {
       spaceBetween: 30,
       centeredSlides: true,

       autoplay: {
       delay: 7500,
       disableOnInteraction: false,
     },
     pagination: {
       el: ".swiper-pagination",
       clickable: true,
     },
     loop:true,
   });
 </script>

<!--swiper js-->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
