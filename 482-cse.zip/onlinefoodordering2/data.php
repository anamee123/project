<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href=".css">
      <!--Link for fa font-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<body>
   <table border= 1 cellspacing = 0 cellpadding = 10>
     <tr>
       <td>4</td>
       <td>Name</td>
       <td>Email</td>
       <td>Maps</td>
     </tr>


     <?php
       require ('config/constants.php');
       $rows = mysqli_query($conn, "SELECT * FROM data ORDER BY id DESC");
       $i = 1;

       foreach($rows as $row) :
     ?>

     <tr>
       <td><?php echo $i++; ?></td>
       <td><?php echo $row["name"]; ?></td>
       <td><?php echo $row["email"]; ?></td>
       <td style="width: 450px; height: 450px;">
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.7367521562287!2d90.41364311397352!3d23.79238679309019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7a1348366e5%3A0x7d15a444ecad8568!2sGulshan%20Pink%20City%20Shopping%20Center%2C%20Gulshan%20Ave%2C%20Dhaka%201212!5e0!3m2!1sen!2sbd!4v1646520364453!5m2!1sen!2sbd" style = "width:100%; height:100%;"></iframe>
       </td>
     </tr>

     <tr>
       <td><?php echo $i++; ?></td>
       <td><?php echo $row["name"]; ?></td>
       <td><?php echo $row["email"]; ?></td>
       <td style="width: 450px; height: 450px;">
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14608.036944845142!2d90.3671072142199!3d23.747050044477056!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b33cffc3fb%3A0x4a826f475fd312af!2sDhanmondi%2C%20Dhaka%201205!5e0!3m2!1sen!2sbd!4v1649955017339!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" style = "width:100%; height:100%;"></iframe>
       </td>
     </tr>


   <?php endforeach; ?>
   </table>
</body>
</html>
