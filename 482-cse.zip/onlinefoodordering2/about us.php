<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<body>
  <div class="wrapper">
    <div class="row">
      <div class="image-section">
        <img src="about-img.png">
      </div>
      <div class="content">
        <h1>About Us</h1>
        <h2>Our Bakery</h2>
        <p>Hello!!Welcome to our restaurents!!You will get some fresh and juicy foods with your desirable taste!!</p>
      </div>

    </div>
  </div>


<br><br>

<br>
</body>
</html>
