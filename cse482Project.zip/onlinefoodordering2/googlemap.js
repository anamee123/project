
 //set map options
 var mylatlng = { lat: 23.8103, lng: 90.4125};
 var mapOptions = {
   center: mylatlng,
   zoom: 7,
   mapTypeId: google.maps.MapTypeId.ROADMAP
 };

 //create maps
 var map = new google.maps.Map(document.getElementById("googleMap"), mapOptions)

//create a directions service object to use the route method and get a result of our request
var directionsService = new google.maps.DirectionsService();

//create a directionsRender for display
var DirectionsDisplay = new google.maps.DirectionsRender();

//bind the directionsRenderer to the map
directionsDisplay.setMap(map);
//function
function calcRoute(){
  //create request
  var request = {
    origin: document.getElementById("from").value,
    destination: document.getElementById("to").value,
    travelMode: google.maps.TravelMode.DEIVING, //walking, ByCycling and transit
    unitSystem: google.maps.UnitSystem.IMPERIAL
  }
  //pass the request method
  directionsService.route(request, (result, status) => {
    if(status == google.maps.DirectionStatus.OK){
      // get distance and time
      const output = document.querySelector('#output');
      output.innerHTML = "<div class= 'alert-info'> From: " + document.getElementById("from").value
                                                            + ".<br />To: " + document.getElementById("to").value
                                                            + ". <br /> Driving Distance <i class="fa fa-road"></i>" + result.routes[0].legs[0].distance.text
                                                            + ".<br />Duration <i class="fa fa-hourglass"></i> : " + result.routes[0].legs[0].duration.text + ".</div>";


    //display the route
    directionsDisplay.setDirections(result);
    }
    else{
      //delete the route
      directionsDisplay.setDirections({routes: []});

      //center map
      map.setCenter(myLating);

      //show error message
      output.innerHTML = "<div class= 'alert-danger'><i class="fa fa-exclamation-triangle"></i> Could Not retrieve the distance. </div>";

    }

  });
}

//create autocomplete objects for all input
var options = {
  types: ['(cities)']
}

var input1 = document.getElementById("from");
var autocomplete1 = new google.maps.places.Autocomplete(input1, options)

var input2 = document.getElementById("to");
var autocomplete2 = new google.maps.places.Autocomplete(input2, options)
