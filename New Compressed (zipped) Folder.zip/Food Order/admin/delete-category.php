<?php

if(isset($_GET['id']) AND isset($_GET['image_name']))
{
  //echo "Get Value and Delete";
  $id = $_GET['id'];
  $image_name = $_GET['image_name'];

  if($image_name != "")
  {
    $path = "../images/category/".$images_name;
  }
}
else
{
  header("location:" .SITEURL.'admin/manage-category.php');
}

?>
