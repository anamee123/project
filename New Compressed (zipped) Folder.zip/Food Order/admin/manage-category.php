<?php include('partials/menu.php'); ?>

<div class="main-content">
  <div class="wraper">
      <h1>Manage Category</h1>

      <br /><br />

      <?php
         if(isset($_SESSION['add']))//checking session set or not
         {

             echo $_SESSION['add'];//display session massage
             unset($_SESSION['add']); //remove session message

         }
      ?>

      <br><br>

      <!--Button to add admin-->
      <a href="<?php echo SITEURL; ?>admin/add-category.php" class="btn-primary">Add Category</a>
       <br /><br /><br />

      <table class="tbl-full">
        <tr>
          <th>Serial Number</th>
          <th>Title</th>
          <th>Image</th>
          <th>Featured</th>
          <th>Active</th>
          <th>Action</th>
        </tr>

        <?php
        //query to get all admin
        $sql = "SELECT * FROM category";
        //execute the query
        $res = mysqli_query($conn, $sql);

          //count rows
          $count = mysqli_num_rows($res); //function to get all the rows
             $sn=1;
           //check num of rows
           if($count>0)
           {
             while($rows=mysqli_fetch_assoc($res))
             {
               $id=$rows['id'];
               $title=$rows['title'];
               $image_name=$rows['image_name'];
               $featured=$rows['featured'];
               $active=$rows['active'];

               ?>

               <tr>
                 <td><?php echo $sn++; ?></td>
                 <td><?php echo $title; ?></td>

                 <td>
                   <?php
                        //check whethe image is available
                        if($image_name!="")
                        {
                          //display the image
                          ?>
                          <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name; ?>" width="100px" >
                          <?php
                        }
                        else
                        {
                          //display the message
                          echo "<div class='error'>Image Not Added</div>";
                        }
                    ?>
                 </td>
                 <td><?php echo $featured; ?></td>
                 <td><?php echo $active; ?></td>
                 <td>
                   <a href="#" class="btn-secondary">Update Category</a>
                   <a href="<?php echo SITEURL; ?>admin/delete-category.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn-danger">Delete Category</a>
                 </td>
               </tr>


               <?php
             }

           }

           else
           {
              ?>

              <tr>
                <td colspan="6"><div class="error">No Category Added</div></td>
              </tr>

              <?php
           }
         ?>

       </table>


  </div>

</div>

<?php include('partials/footer.php'); ?>
